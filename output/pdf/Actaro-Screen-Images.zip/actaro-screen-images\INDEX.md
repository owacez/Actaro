# Actaro screen images

Fictional sample data. Full scrolling content at 390 logical pixels, exported at 2x. Source-derived variants are identified below.

01. Today - PDF page 5 - Rendered app reference
02. Fitness · Exercise Library - PDF page 6 - Rendered app reference
03. Nutrition diary - PDF page 7 - Rendered app reference
04. Progress · Weight - PDF page 8 - Rendered app reference
05. More - PDF page 9 - Rendered app reference
06. Exercise filters - PDF page 10 - Rendered app reference
07. Exercise detail - PDF page 11 - Rendered app reference
08. Workout preview - PDF page 12 - Rendered app reference
09. Workout mode - PDF page 13 - Rendered app reference
10. Timed workout - PDF page 14 - Rendered app reference
11. Log Only workout - PDF page 15 - Rendered app reference
12. Workout summary - PDF page 16 - Rendered app reference
13. Habits - PDF page 17 - Rendered app reference
14. Goals & progress - PDF page 18 - Rendered app reference
15. Sign in - PDF page 19 - Rendered app reference
16. Sign up - PDF page 20 - Rendered app reference
17. Password reset - PDF page 21 - Rendered app reference
18. Food search results - PDF page 22 - Rendered app reference
19. Food portion - PDF page 23 - Rendered app reference
20. Edit food log - PDF page 24 - Rendered app reference
21. Recipe editor - PDF page 25 - Rendered app reference
22. Workout builder - PDF page 26 - Rendered app reference
23. Training plan library - PDF page 27 - Rendered app reference
24. Training plan preview - PDF page 28 - Rendered app reference
25. Workout history - PDF page 29 - Rendered app reference
26. Edit recorded workout - PDF page 30 - Rendered app reference
27. Habit editor - PDF page 31 - Rendered app reference
28. Goal editor - PDF page 32 - Rendered app reference
29. Edit saved goal - PDF page 33 - Rendered app reference
30. Custom food editor - PDF page 34 - Rendered app reference
31. Saved meals - PDF page 35 - Rendered app reference
32. Profile management - PDF page 36 - Rendered app reference
33. Preferences - PDF page 37 - Rendered app reference
34. My workouts - PDF page 38 - Rendered app reference
35. Training splits - PDF page 39 - Rendered app reference
36. Seven-day split editor - PDF page 40 - Rendered app reference
37. Training summary - PDF page 41 - Rendered app reference
38. Recovery check - PDF page 42 - Rendered app reference
39. Available equipment - PDF page 43 - Rendered app reference
40. Privacy & account data - PDF page 44 - Rendered app reference
41. Habit reminders · web - PDF page 45 - Rendered app reference
42. Profile · Change email - PDF page 46 - Rendered app reference
43. Profile · Change password - PDF page 47 - Rendered app reference
44. Daily nutrition targets - PDF page 48 - Rendered app reference
45. Recipes - PDF page 49 - Rendered app reference
46. Log habit - PDF page 50 - Rendered app reference
47. Habit history - PDF page 51 - Rendered app reference
48. Body records · Weight - PDF page 52 - Rendered app reference
49. Body records · Measurements - PDF page 53 - Rendered app reference
50. Steps & activity - PDF page 54 - Rendered app reference
51. Progress · Nutrition - PDF page 55 - Rendered app reference
52. Progress · Frequency - PDF page 56 - Rendered app reference
53. Progress · Strength - PDF page 57 - Rendered app reference
54. Progress · Volume - PDF page 58 - Rendered app reference
55. Progress · Steps - PDF page 59 - Rendered app reference
56. Progress · Habits - PDF page 60 - Rendered app reference
57. Progress · Summary - PDF page 61 - Rendered app reference
58. Food search · Initial - PDF page 62 - Rendered app reference
59. New workout · Empty - PDF page 63 - Rendered app reference
60. Email verification instructions - PDF page 64 - Rendered app reference
61. Recovery · Set password - PDF page 65 - Rendered app reference
62. Email confirmed - PDF page 66 - Rendered app reference
63. Auth link · Error - PDF page 67 - Rendered app reference
64. Email change · Other inbox - PDF page 68 - Rendered app reference
65. Sign in · Validation & toast - PDF page 69 - Rendered app reference
66. Preferences · Dark - PDF page 70 - Rendered app reference
67. Today · Dark - PDF page 71 - Rendered app reference
68. Nutrition · Dark - PDF page 72 - Rendered app reference
69. Progress · Dark - PDF page 73 - Rendered app reference
70. More · Dark - PDF page 74 - Rendered app reference
71. Save meal template - PDF page 75 - Rendered app reference
72. Recipe ingredient selection - PDF page 76 - Rendered app reference
73. Workout builder · Set editor - PDF page 77 - Rendered app reference
74. Workout · Rest timer - PDF page 78 - Rendered app reference
75. Workout · Paused - PDF page 79 - Rendered app reference
76. Workout · Discard confirmation - PDF page 80 - Rendered app reference
77. Deleted habits - PDF page 81 - Rendered app reference
78. Deleted goals - PDF page 82 - Rendered app reference
79. Exercise search · Empty - PDF page 83 - Rendered app reference
80. Exercise detail · Retry - PDF page 84 - Rendered app reference
81. Goals - empty - PDF page 85 - Rendered app reference
82. Goal editor - daily steps - PDF page 86 - Rendered app reference
83. Seven-day split - new - PDF page 87 - Rendered app reference
84. Habit reminders - native - PDF page 88 - Source-derived native branch; OS permission sheet excluded
85. Steps & activity - iPhone - PDF page 89 - Source-derived iPhone branch; safe-area and OS permission UI excluded
86. Sign in - mobile snackbar - PDF page 90 - Source-derived mobile feedback; OS safe-area inset varies by device
87. Progress - custom date range - PDF page 91 - Source-derived expanded date controls
