# Asset attribution

Exercise data and illustrations by [RepDB](https://repdb.co).

Food catalog content in the demonstrated UI originates from USDA FoodData Central.
Screen values and account details are fictional demonstration data.

The images document Actaro's current implementation. Native-only source-derived
variants are labelled in INDEX.md; these are not physical-device screenshots.
